rm(list=ls()) # Removes everything from the memory
setwd("SET YOUR OWN PATH HERE")

set.seed(3749) # Seed value for the random number generator (always set this to make your results replicable)

# Define number of subjects and observations per subject
n_U  <- 30 # Number of subjects in Type U
n_P  <- 70 # Number of subjects in Type P
obs <- 5   # Number of observations per subject

# Define parameters for the simulation
const_U <- 1       # Constant of Type U
const_P <- 6       # Constant of Type P
beta_U  <-  1.5    # Type-specific reaction to training of Type U
beta_P  <- -0.7    # Type-specific reaction to training of Type P
gamma  <- c(.2,.1) # Common slope parameters for years of experience and age)
sigma_U <- 1       # Standard deviation of the error term of Type U
sigma_P <- 1       # Standard deviation of the error term of Type P

# Generate observations of the regressors of Type U
train_U <- runif(n_U*obs, 0, 5)   # Intensity of training of Type U: uniformely distributed on [0,5]
exper_U <- runif(n_U*obs, 0,10)   # Years of experience of Type U: uniformely distributed on [0,10]
age_U   <- runif(n_U*obs,  20,60) # Age of Type U: uniformely distributed on [20,60]

# Generate observations of the regressors of Type P
train_P <- runif(n_P*obs, 0, 5)   # Intensity of training of Type P: uniformely distributed on [0,5]
exper_P <- runif(n_P*obs, 0,10)   # Years of experience of Type P: uniformely distributed on [0,10]
age_P   <- runif(n_P*obs,  20,60) # Age of Type P: uniformely distributed on [20,60]

# Simulating the outcome variable of types 1 and 2 -- i.e., simulating the data generating process
y_U <- const_U + train_U*beta_U + exper_U*gamma[1] + age_U*gamma[2] + rnorm(n_U*obs, mean=0, sd=sigma_U)
y_P <- const_P + train_P*beta_P + exper_P*gamma[1] + age_P*gamma[2] + rnorm(n_P*obs, mean=0, sd=sigma_P)

data <- data.frame(
	SubjID = rep(1:(n_U+n_P), times=1, each=obs),
	const  = rep(1, n_U+n_P), 
	train  = c(train_U, train_P),
	exper  = c(exper_U, exper_P),
	age    = c(age_U, age_P),
	prod   = c(y_U, y_P)
)

write.table(data, "simulated_data.csv", sep=",", col.names=T, row.names=F)
