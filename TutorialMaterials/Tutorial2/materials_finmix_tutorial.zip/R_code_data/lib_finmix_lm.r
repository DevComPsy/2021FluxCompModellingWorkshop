####################################################################################################################################
#                                                                                                                                  #
# FUNCTIONS FOR ESTIMATING THE FINITE MIXTURE VERSION OF A LINEAR REGRESSION MODEL                                                 #
# ================================================================================                                                 #
#                                                                                                                                  #
# Author: Adrian Bruhin, adibru@gmx.net                                                                                            #
#                                                                                                                                  #
# Date: January 30, 2020                                                                                                           #
#                                                                                                                                  #
# License: You can use this code or parts of it only for non-commercial and scientific purposes. Commercial and/or for profit use  #
# is prohibited. Please do neither distribute nor sell this code.                                                                  #
#                                                                                                                                  #
# If you use this code or parts of it, please cite at least one of the below papers that apply finite mixture models -- thank you! #
#                                                                                                                                  #
# - Bruhin et al. (2015): "Call of duty: the effects of phone calls on blood donor motivation", Transfusion, 55 (11), 2645-2652.   #
#                                                                                                                                  #
# - Bruhin et al. (2019): "The many faces of human sociality: Uncovering the distribution and stability of social preferences",    #
#   Journal of the European Ecoonomic Association, 17 (4), 1025-1069.                                                              #
#                                                                                                                                  #
# - Bruhin et al. (2010): "Risk and rationality: Uncovering heterogeneity in probability distortion", Econometrica, 78 (4),        #
#   1375-1412.                                                                                                                     #
#                                                                                                                                  #
# Disclaimer: The author takes no responsibility for any mistakes in the code or its use.                                          #
#                                                                                                                                  #
####################################################################################################################################

library(compiler) # Necessary for pre-compiling the functions

# Component density function
f.compdens <- function(v,  yvec, xmat, zmat,  selvec, njmax, j, nc, xk, zk, pid) {
	ret <- matrix(0,j,nc, dimnames=list(pid,paste("cl",1:nc)))

	zpart <- as.vector(zmat %*% v[(nc*xk+1):(nc*xk+zk)])

	for (c in 1:nc) {
		yhat <- as.vector(xmat %*% v[((c-1)*xk+1):(c*xk)]) + zpart
		dens <- dnorm(yvec, yhat, exp(v[nc*xk+zk+1]))
		densl <- rep(1, length(selvec))
		densl[selvec] <- dens
		densm <- matrix(densl, njmax, j)
		for(i in 1:j) {ret[i,c] <- prod(densm[,i])} # unfortunately not possible to avoid the for loop
	}
	ret
}
f.compdens <- cmpfun(f.compdens)

# Gradient of the component density function
f.gr.compdens <- function(v, yvec, xmat, zmat, selvec, njmax, j, nc, xk, zk, pid) {
	betagrad  <- matrix(0, j, nc*xk)
	gammagrad <- matrix(0, j, nc*zk)
	sigmagrad <- matrix(0, j, nc)
	retcd     <- matrix(0, j, nc)

	gamma <- v[(nc*xk+1):(nc*xk+zk)]
	sigma <- exp(v[nc*xk+zk+1])

	zpart <- as.vector(zmat %*% gamma)

	for (c in 1:nc) {
		beta <- v[((c-1)*xk+1):(c*xk)]
		yhat <- as.vector(xmat %*% beta) + zpart
		dens <- dnorm(yvec, yhat, sigma)

		inner   <- (yvec-yhat)/sigma^2
		pregrad.beta  <- xmat * matrix(inner, length(inner), xk)
		pregrad.gamma <- zmat * matrix(inner, length(inner), zk)

		pregrad.sigma <- (yvec-yhat)^2/sigma^2 - 1

		densl <- rep(1, length(selvec))
		densl[selvec] <- dens
		densm <- matrix(densl, njmax, j)

		pregrad.betal <- rep(0, length(selvec)*xk)
		pregrad.betal[rep(selvec,xk)] <- as.vector(pregrad.beta)
		pregrad.betam <- matrix(pregrad.betal, njmax, j*xk)

		pregrad.gammal <- rep(0, length(selvec)*zk)
		pregrad.gammal[rep(selvec,zk)] <- as.vector(pregrad.gamma)
		pregrad.gammam <- matrix(pregrad.gammal, njmax, j*zk)

		pregrad.sigmal <- rep(0, length(selvec))
		pregrad.sigmal[selvec] <- pregrad.sigma
		pregrad.sigmam <- matrix(pregrad.sigmal, njmax, j)

		for(i in 1:j) {retcd[i,c] <- prod(densm[,i])}
		sigmagrad[,c]                            <- colSums(pregrad.sigmam) * retcd[,c]
		betagrad[, ((c-1)*xk+1):(c*xk)]          <- matrix(colSums(pregrad.betam),  j,   xk) * matrix(retcd[,c],j, xk)
		gammagrad[,((c-1)*zk+1):(c*zk)]  <- matrix(colSums(pregrad.gammam), j, zk) * matrix(retcd[,c], j, zk)
	}
	list(compdens=retcd, beta=betagrad, gamma=gammagrad, sigma=sigmagrad)
}
f.gr.compdens <- cmpfun(f.gr.compdens)


# Log likelihood function of the K=1 model
f.totloglik1 <- function(psi,  yvec, xmat, zmat,  selvec, njmax, j, xk, zk) {
	yhat <- as.vector(xmat %*% psi[1:xk]) + as.vector(zmat %*% psi[(xk+1):(xk+zk)])
	dens <- dnorm(yvec, yhat, exp(psi[xk+zk+1]))
	sum( log(dens) )
}
f.totloglik1 <- cmpfun(f.totloglik1)

# Log likelihood function of the whole finite mixture model
f.totloglik <- function(psi,  yvec, xmat, zmat,  selvec, njmax, j, nc, xk, zk, pid) {
	v   <- psi[1:(nc*xk+zk+1)]
	mix <- psi[(nc*xk+zk+2):length(psi)]
	mix <- c(mix, 1-sum(mix))
	m   <- matrix(mix, j, nc, byrow=T)
	mcd <- rowSums( m * f.compdens(v, yvec, xmat, zmat, selvec, njmax, j, nc, xk, zk, pid) )
	sum( log(mcd) )
}
f.totloglik <- cmpfun(f.totloglik)

# Gradient of the log likelihood function of the whole finite mixture model
f.gr.totloglik <- function(psi, yvec, xmat, zmat, selvec, njmax, j, nc, xk, zk, pid) {
	v   <- psi[1:(nc*xk+zk+1)]
	mix <- psi[(nc*xk+zk+2):length(psi)]
	mix <- c(mix, 1-sum(mix))

	gcd <- f.gr.compdens(v, yvec, xmat, zmat, selvec, njmax, j, nc, xk, zk, pid)

	m     <- matrix(mix, j, nc, byrow=T)
	outer <- 1/rowSums( m * gcd$compdens )

	#beta gradient
	mb <- matrix(as.vector(matrix(mix,   j*xk, nc, byrow=T)), j, nc*xk)
	ob <- matrix(outer, j, nc*xk)
	betagrad <- colSums(gcd$beta * mb * ob)

	#gamma gradient
	mg <- matrix(as.vector(matrix(mix,   j*zk, nc, byrow=T)), j, nc*zk)
	og <- matrix(outer, j, nc*zk)
	gammagrad <- colSums(gcd$gamma * mg * og)
	gammagrad <- rowSums(matrix(gammagrad, zk, nc))

	#sigma gradient
	sigmagrad <- sum(gcd$sigma * m * matrix(outer, j, nc, byrow=F))

	#mix gradient
	mixgrad <- colSums((gcd$compdens - matrix(gcd$compdens[,nc],j,nc)) * matrix(outer, j, nc, byrow=F))

	c(betagrad, gammagrad, sigmagrad, mixgrad[1:(nc-1)])
}
f.gr.totloglik <- cmpfun(f.gr.totloglik)

# Sandwich and degrees of freedom of the cluster robust VC estimator
f.sandwich <- function(psi, yvec, xmat, zmat, selvec, njmax, j, nc, xk, zk) {
	v   <- psi[1:(nc*xk+zk+1)]
	mix <- psi[(nc*xk+zk+2):length(psi)]
	mix <- c(mix, 1-sum(mix))

	gcd <- f.gr.compdens(v, yvec, xmat, zmat, selvec, njmax, j, nc, xk, zk)

	m     <- matrix(mix, j, nc, byrow=T)
	outer <- 1/rowSums( m * gcd$compdens )

	#beta gradient
	mb <- matrix(as.vector(matrix(mix,   j*xk, nc, byrow=T)), j, nc*xk)
	ob <- matrix(outer, j, nc*xk)
	betagradi <- gcd$beta * mb * ob

	#gamma gradient
	mg <- matrix(as.vector(matrix(mix,   j*zk, nc, byrow=T)), j, nc*zk)
	og <- matrix(outer, j, nc*zk)
	gammagradnc <- gcd$gamma * mg * og
	gammagradi <- matrix(0, j, zk)
	for (c in 1:nc) {
		gammagradi <- gammagradi + gammagradnc[,((c-1)*zk+1):(c*zk)]
	}

	#sigma gradient
	sigmagradi <- as.matrix(rowSums(gcd$sigma * m * matrix(outer, j, nc, byrow=F)))

	#mix gradient
	mixgradi <- (gcd$compdens - matrix(gcd$compdens[,nc],j,nc)) * matrix(outer, j, nc, byrow=F)

	# Matrix of individual gradient contributions
	gradi <- cbind(betagradi, gammagradi, sigmagradi, mixgradi[,1:(nc-1)])

	# Compute the sandwich part of the sandwich VC estimator
	sandwich <- matrix(0, ncol(gradi), ncol(gradi))
	for (i in 1:j) {
		sandwich <- sandwich + (gradi[i,] %o% gradi[i,])
	}

	qc <- (length(yvec)-1)/(length(yvec)-ncol(gradi)) * j/(j-1) #Degrees of freedom adjustment

	list(qc=qc, sandwich=sandwich)
}
f.sandwich <- cmpfun(f.sandwich)

# Log likelihood function of the M-step
f.mloglik <- function(v, yvec, xmat, zmat, selvec, njmax, j, nc, xk, zk, tau, pid) {
	sum( tau * log(f.compdens(v, yvec, xmat, zmat, selvec, njmax, j, nc, xk, zk, pid)) )
}
f.mloglik <- cmpfun(f.mloglik)

# Gradient of the log likelihood function of the M-step
f.gr.mloglik <- function(v, yvec, xmat, zmat, selvec, njmax, j, nc, xk, zk, tau, pid) {
	gcd <- f.gr.compdens(v, yvec, xmat, zmat, selvec, njmax, j, nc, xk, zk, pid)

	#beta gradient
	sel <- as.vector(matrix(1:nc,xk,nc, byrow=T))
	betagrad <- colSums( tau[, sel] * gcd$beta/gcd$compdens[, sel] )

	#gamma gradient
	sel <- as.vector(matrix(1:nc,zk,nc,byrow=T))
	gammagrad <- colSums( tau[, sel] * gcd$gamma/gcd$compdens[, sel] )
	gammagrad <- rowSums(matrix(gammagrad,zk,nc))

	#sigma gradient
	sigmagrad <- sum( tau * gcd$sigma/gcd$compdens )

	c(betagrad, gammagrad, sigmagrad)
}
f.gr.mloglik <- cmpfun(f.gr.mloglik)

# E-Step function
f.estep <- function(v, yvec, xmat, zmat, selvec, njmax, j, nc, xk, zk, mix, pid) {
	m   <- matrix(mix, j, nc, byrow=T)
	num <- m * f.compdens(v, yvec, xmat, zmat, selvec, njmax, j, nc, xk, zk, pid)
	den <- matrix(rowSums(num), j, nc)
	ret <- num/den
	dimnames(ret) <- list(pid, paste("cl",1:nc))
	ret
}
f.estep <- cmpfun(f.estep)

# S-Step function (for the version of the EM algorithm using simulated annealing)
f.sstep <- function(em.tau){
	sem.tau <- matrix(0,nrow(em.tau),ncol(em.tau), dimnames=dimnames(em.tau))
	for (i in 1:nrow(em.tau)) {
		sem.tau[i,] <- t(rmultinom(1,1,em.tau[i,]))
	}
	sem.tau
}
f.sstep <- cmpfun(f.sstep)

# M-Step function
f.mstep <- function(v, yvec, xmat, zmat, selvec, njmax, j, nc, xk, zk, tau, pid) {
	ret <- optim(v, f.mloglik, f.gr.mloglik, method="BFGS", control=list(maxit=10000, trace=0, fnscale=-1), hessian=F, yvec=yvec, xmat=xmat, zmat=zmat, selvec=selvec, njmax=njmax, j=j, nc=nc, xk=xk, zk=zk, tau=tau, pid=pid)
	mix <- colMeans(tau)
	list(mix=mix, v=ret$par)
}
f.mstep <- cmpfun(f.mstep)

#Annealing Part Function of the version of the EM algorithm using simulated annealing
f.annealing <- function(em.mix, em.vm, sem.mix, sem.vm, iter, b=20){
	{if (iter <= b)
		{q <- cos((iter/b)*acos(b/100))}
	 else
		{q <- (b/100)*sqrt(b/iter)}
	}

	mix <- q*sem.mix+(1-q)*em.mix
	vm  <- q*sem.vm+(1-q)*em.vm

	list(mix=mix, vm=vm)
}
f.annealing <- cmpfun(f.annealing)

f.estim <- function(
	datin,                  # Data frame containing all data for the estimation
	pind,                   # Name of the (numerical) variable containing the Subject IDs
	yind,                   # Name of the (numerical) dependent variable
	xind,                   # Vector with the names of the (numerical) type-specific regressors: needs to have at least one element
	zind,                   # Vector with the names of the (numerical) common regressors: needs to have at least one element
	nc        = 2,          # number of types
	algorithm = "EM",       # whether the "EM" or "SAEM" algorithm should be used
	maxemiter = 50,         # maximum number of EM-type iterations before switching to direct ML estimation
        diffcrit  = 5e-3,   # if EM-type progress falls below this criterum => switch to direct ML estimation
        v0        = NULL,   # initial values for the finmix estimation. If NULL generate random initial values
	compse    = T,          # should information based standard errors be computed?
	silent    = F           # suppress output (for example for bootstrapping)
) {

	dat <- datin[order(datin[,pind]),]
	xmat <- as.matrix(dat[,xind])
	zmat <- as.matrix(dat[,zind])
	yvec <- as.vector(dat[,yind])
	xk <- length(xind)
	zk <- length(zind)
	n  <- length(yvec)

	pvec  <- as.vector(datin[,pind])
	pid   <- unique(pvec)
	j     <- max(pid)
	tp    <- table (pvec) 
	njmax <- max(tp)

	# Handling of a balanced vs. an unbalanced panel
	if (sd(tp) == 0) {
		paneltype <- "balanced"
		selvec    <- rep(T, j*njmax)
	} else {
		selvec <- rep(F, j*njmax)
		for (i in 1:j) {
			paneltype    <- "unbalanced"
			selT         <- ((i-1)*njmax + 1):((i-1)*njmax + tp[i])
			selvec[selT] <- T
		}
	}

	# Start values: coefficients form a standard linear regression model + random distrubances
	reg <- lm(yvec ~ xmat + zmat - 1)
	if (is.null(v0)) {
		beta0        <- reg$coefficients[1:xk]
		disturb      <- matrix(c(runif(nc,0.5,1.5),runif((xk-1)*nc, -2, 2)), xk, nc, byrow=T) # First coefficent is probably the constant
		beta0        <- as.vector(matrix(beta0, xk, nc) * disturb)
		gamma0       <- reg$coefficients[(xk+1):(xk+zk)] * runif(zk, 0.9, 1.1)
		sigma0       <- log(sqrt(sum(reg$residuals^2)/n) * runif(1, 1.5,3))
		aa           <- runif(nc,1,10)
		mix0         <- aa/sum(aa)
		mix0         <- mix0[1:(nc-1)]
		v0    <- c(beta0, gamma0, sigma0, mix0)
	}
	psic1 <- c(reg$coefficients)
	psic1 <- c(psic1,log(sqrt(sum(reg$residuals^2)/n)))

	aa  <- as.vector(matrix(rep(paste("cl",1:nc,sep=""), xk), xk, nc, byrow=T))
	nam <- c(paste(colnames(xmat),aa,sep="_"), colnames(zmat), "sigma", paste("mix",1:(nc-1),sep="_"))
	names(v0) <- nam

	# Calculate the initial log likelihood for the K=1 and the finite mixture model
	llc1  <- f.totloglik1(psic1,  yvec, xmat, zmat,  selvec, njmax, j, xk, zk)
	llold <- f.totloglik(v0   ,  yvec, xmat, zmat,  selvec, njmax, j, nc, xk, zk, pid)
	if (silent==F) {
		cat("\nLog likelihood K=1 model:", round(llc1,2))
		cat("\n\nStart values:", round(as.matrix(v0),4))
		cat("\nInitial log likelihood:  ", round(llold,2))
		cat("\n\nStarting",algorithm,"maximization...\n")
	}

	# control flow of the EM/SAEM algorithm (SAEM is the version using simulated annealing)
	iter <- 1
	diff <- 1
	llnew <- llold

	v   <- v0[1:(nc*xk+zk+1)]
	mix <- v0[(nc*xk+zk+2):length(v0)]
	mix <- c(mix,1-sum(mix))

	# EM/SAEM algorithm
	while (iter < maxemiter + 1 & abs(diff) > diffcrit) {

		if(silent==F) {
			cat("\n  ",algorithm,"iteration", iter,"of max.", maxemiter,"\n")
			cat("    working on E-step (EM-algorithm)\n")
		}

		tau.em <- f.estep(v, yvec, xmat, zmat, selvec, njmax, j, nc, xk, zk, mix, pid)
		if (silent==F) {cat("    working on M-step (EM algorithm)\n")}

		mstep  <- f.mstep(v, yvec, xmat, zmat, selvec, njmax, j, nc, xk, zk, tau.em, pid)
		v.em   <- mstep$v
		mix.em <- mstep$mix

		if (algorithm == "SAEM") {

			if (silent==F) {cat("    working on E-step (SEM algorithm)\n")}
			tau.sem <- f.sstep(tau.em)

			if (silent==F) {cat("    working on M-step (SEM algorithm)\n")}
			mstep   <- f.mstep(v, yvec, xmat, zmat, selvec, njmax, j, nc, xk, zk, tau.sem, pid)
			v.sem   <- mstep$v
			mix.sem <- mstep$mix

			ann <- f.annealing(mix.em, v.em, mix.sem, v.sem, iter, b=20)
			mix <- ann$mix
			v   <- ann$vm

		} else {

			mix <- mix.em
			v   <- v.em

		}

		iter  <- iter + 1
		llold <- llnew
		psi   <- c(v, mix[1:(nc-1)])
		llnew <- f.totloglik(psi,  yvec, xmat, zmat,  selvec, njmax, j, nc, xk, zk, pid)
		diff  <- llnew-llold

		if (silent == F) {
			cat("    Achieved log likelihood:", round(llnew,4))
			cat("\n    Progress made:", round(diff,4))
			cat("\n    Actual parameter vector:\n")
			print(round(psi,4),quote=F)
		}
	}

	# Switch to direct maximization of the log likelihood
	tra <- 0
	if(silent==F) {
		cat("\n\nSwitching to direct ML estimation\n")
		tra <- 1
	}
	ret <-  optim(psi, f.totloglik, f.gr.totloglik, method="BFGS", control=list(maxit=100000, trace=tra, REPORT=10, fnscale=-1), hessian=compse, yvec=yvec, xmat=xmat, zmat=zmat, selvec=selvec, njmax=njmax, j=j, nc=nc, xk=xk, zk=zk, pid=pid)

	# Extract the estimated parameters and calculate the ex-post probabilites of type-membership
	np    <- length(ret$par)
	beta  <- ret$par[1:(nc*xk)]
	gamma <- ret$par[(nc*xk+1):(nc*xk+zk)]
	sigma <- exp(ret$par[nc*xk+zk+1])
	mix   <- ret$par[(nc*xk+zk+2):np]
	mix   <- c(mix, 1-sum(mix))
	tau   <-  f.estep(ret$par[1:(nc*xk+zk+1)], yvec, xmat, zmat, selvec, njmax, j, nc, xk, zk, mix, pid) # ex-post probabilities of type-membership

	# Compute standard errors (standard and individual cluster robust)
	se   <- rep(NA, np+1)
	vcm  <- matrix(NA,np,np)
	ser  <- se
	vcmr <- vcm
	if (compse) {
		# Standard errors
		vcm <- solve(-ret$hessian)
		se  <- sqrt(diag(vcm))
		se[nc*xk+zk+1] <- sqrt(exp(2*ret$par[nc*xk+zk+1])*vcm[nc*xk+zk+1,nc*xk+zk+1])
		mixvar <- matrix(1,1,nc-1) %*% as.matrix(vcm[(nc*xk+zk+2):np, (nc*xk+zk+2):np]) %*% matrix(1,nc-1,1)
		se <- c(se, sqrt(mixvar))

		# Cluster robust standard errors
		sandwich <- f.sandwich(ret$par, yvec, xmat, zmat, selvec, njmax, j, nc, xk, zk)
		vcmr <- sandwich$qc * (vcm %*% sandwich$sandwich %*% vcm)
		ser  <- sqrt(diag(vcmr))
		ser[nc*xk+zk+1] <- sqrt(exp(2*ret$par[nc*xk+zk+1])*vcmr[nc*xk+zk+1,nc*xk+zk+1])
		mixvarr <- matrix(1,1,nc-1) %*% as.matrix(vcmr[(nc*xk+zk+2):np, (nc*xk+zk+2):np]) %*% matrix(1,nc-1,1)
		ser <- c(ser, sqrt(mixvarr))

	}

	# Preparation of output
	beta.se  <- se[1:(nc*xk)]
	gamma.se <- se[(nc*xk+1):(nc*xk+zk)]
	sigma.se <- sqrt(exp(2*ret$par[nc*xk+zk+1])*vcm[nc*xk+zk+1,nc*xk+zk+1])
	mix.se   <- se[(nc*xk+zk+2):(np+1)]

	beta.pv  <- 2*(1-pnorm(abs(beta)/beta.se))
	gamma.pv <- 2*(1-pnorm(abs(gamma)/gamma.se))

	beta.str  <- symnum(beta.pv,  c(0,.001,.01,.05,.1,1),c('***','** ','*  ','.  ','   '))
	gamma.str <- symnum(gamma.pv, c(0,.001,.01,.05,.1,1),c('***','** ','*  ','.  ','   '))

	beta.ser  <- ser[1:(nc*xk)]
	gamma.ser <- ser[(nc*xk+1):(nc*xk+zk)]
	sigma.ser <- sqrt(exp(2*ret$par[nc*xk+zk+1])*vcmr[nc*xk+zk+1,nc*xk+zk+1])
	mix.ser   <- ser[(nc*xk+zk+2):(np+1)]

	beta.pvr  <- 2*(1-pnorm(abs(beta)/beta.ser))
	gamma.pvr <- 2*(1-pnorm(abs(gamma)/gamma.ser))

	beta.strr  <- symnum(beta.pvr,  c(0,.001,.01,.05,.1,1),c('***','** ','*  ','.  ','   '))
	gamma.strr <- symnum(gamma.pvr, c(0,.001,.01,.05,.1,1),c('***','** ','*  ','.  ','   '))

	aic  <- -2*ret$value + 2*np
	bic  <- -2*ret$value + log(n)*np
	aic1 <- -2*llc1 + 2     *(np-xk*(nc-1)-(nc-1))
	bic1 <- -2*llc1 + log(n)*(np-xk*(nc-1)-(nc-1))

	tauv  <- as.vector(tau)
	tmax  <- rep(apply(tau,1,max),nc)
	tauhv <- as.numeric(tauv==tmax)
	tauh  <- matrix(tauhv, j, nc, dimnames=dimnames(tau))

	nec  <- sum(na.omit(-tauv*log(tauv)))/(ret$value-llc1)
	icl  <- bic - 2*sum(na.omit(tauv*log(tauv)))
	nec1 <- 1
	icl1 <- bic1

	critmat <- matrix(c(aic,bic,nec,icl, aic1,bic1,nec1,icl1), 4,2, dimnames=list(c("AIC","BIC","NEC","ICL"),c(paste("K=",nc,sep=""),"K=1")))

	beta.out <- matrix("|",xk,nc*5, dimnames=list(colnames(xmat), paste(c("pe_","se_","pv_","si_",""),as.vector(rbind(matrix(1:nc,4,nc,byrow=T),rep("|",nc))),sep="")))
	for (c in 1:nc) {
		sel <- ((c-1)*xk+1):(c*xk)
		beta.out[,((c-1)*5+1):(c*5-1)] <- c(round(beta[sel],3), round(beta.ser[sel],3), round(beta.pvr[sel],3), beta.strr[sel])
	}

	gamma.out <- matrix(c(round(gamma,3), round(gamma.ser,3), round(gamma.pvr,3), gamma.strr), zk, 4, dimnames=list(colnames(zmat), c("pe","se","pv","si")))

	sigma.out <- matrix(c(round(sigma,3), round(sigma.ser,3)), 1, 2, dimnames=list("sigma", c("pe","se")))

	mix.out <- matrix(c(round(mix,3), round(mix.ser,3)), 2, nc, byrow=T, dimnames=list(c("pe","se"), paste("mix",1:nc,sep="")))

	if (silent==F) {
		cat("\n\n\nESTIMATION RESULTS K=",nc," FINITE MIXTURE MODEL\n\n", sep="")
		cat("Log Likelihood K=1 Model:",round(llc1,2),"\n")
		cat("Log Likelihood K=",nc," Model: ", round(ret$value,2), "\n", sep="")
		cat("\nPanel:", paneltype,"\n")
		cat("# of Observations:", n, "\n")
		cat("# of Individuals:", j, "\n")
		cat("# of Parameters:", np, "\n\n")
		print(round(critmat,2))
		cat("\n\nPARAMETER ESTIMATES (INCL. INDIVIDUAL CLUSTER ROBUST STANDARD ERRORS):\n\n")
		print(beta.out,quote=F)
		cat("\n")
		print(gamma.out, quote=F)
		cat("\n")
		print(sigma.out, quote=F)
		cat("\n")
		print(mix.out, quote=F)
	}

	list(ret=ret, par=list(beta=beta, gamma=gamma, sigma=sigma, mix=mix), par.se=list(beta.se=beta.se, gamma.se=gamma.se, sigma.se=sigma.se, mix.se=mix.se), par.ser=list(beta.ser=beta.ser, gamma.ser=gamma.ser, sigma.ser=sigma.ser, mix.ser=mix.ser), vcm=vcm, vcmr=vcmr, critmat=critmat, tau=tau, tauh=tauh, outmat=list(beta.out=beta.out, gamma.out=gamma.out, sigma.out=sigma.out, mix.out=mix.out), llc1=llc1, reg1=reg$coefficients, nc=nc, n=n, j=j, np=np, iter=iter, paneltype=paneltype, tp=tp, v0=v0)
}
f.estim <- cmpfun(f.estim)
