options(width=100) #Display maximally 100 characters before line break
rm(list=ls()) # Removes everything from the memory
setwd("SET YOUR OWN PATH HERE")

# Load the simulated data
data <- read.table("simulated_data.csv", sep=",", header=T)


# Estimate the relationship between training intensity and productivity
# at the aggregate level
reg <- lm(prod ~ train + exper + age, data=data)
print(summary(reg))

# Plot the aggregate effect of training intensity on productivity
# for individuals with average experience and average age
const <- reg$coefficients["(Intercept)"] + mean(data$exper)*reg$coefficients["exper"] + mean(data$age)*reg$coefficients["age"]
beta  <- reg$coefficients["train"]

pdf("plot_before_estim.pdf", width=8, height=6)
	plot(data$train, data$prod, main="Avg. Effect of Training on Productivity (K=1 Model)", xlab="train", ylab="prod")
	abline(const, beta)
dev.off()



# Load the functions for estimating the linear finite mixture model
source("lib_finmix_lm.r") 

set.seed(512) # Set a seed value for the random number generator (do this to make your results replicable!)

# Run the finite mixture estimation with K=2 types
result <- f.estim(
	datin = data,                # Data set used for the estimation
	pind  = "SubjID",            # Name of the Subject ID (which has to be numeric)
	yind  = "prod",              # Name of the dependent variable (which has to be numeric)
	xind  = c("const","train"),  # Names of the type-specific regressors (which have to be numeric; the constant should be first)
	zind  = c("exper", "age"),   # Names of the common regressors (which have to be numeric)
	nc    = 2,                   # Number of types
	algorithm = "EM"             # Whether to use the standard ("EM") or the simulated annealing version ("SAEM") of the EM algorithm
)

# Plot the histograms of the ex post probabilities of individual type-membership
pdf("tau_hist.pdf", width=8, height=6)
	hist(result$tau[,1],40, main="Pr. of being in Type 1 (K=2 Model)", xlab=expression(tau[1]))
dev.off()

# Add individual type-membership to data
tauh <- result$tauh
typematrix <- cbind(as.numeric(rownames(tauh)), tauh) # Matrix containing the Subject IDs in the 1st column and the indicators of type-membership in the following colums
colnames(typematrix) <- c("SubjID", "type1", "type2") # Add the column names
data <- merge(data, typematrix, by="SubjID")          # Add the indicators of type membership to the data

# Color codes for types
data[data$type1 == 1, "type_color"] <- "#ff0000" # Red  for type 1
data[data$type2 == 1, "type_color"] <- "#0000ff" # Blue for type 2

# Plot the type-specific effect of training intensity on productivity
# for individuals with average experience and average age
const1 <- result$par$beta["const_cl1"] + mean(data[data$type1 == 1, "exper"])*result$par$gamma["exper"] + mean(data[data$type1 == 1, "age"])*result$par$gamma["age"]
const2 <- result$par$beta["const_cl2"] + mean(data[data$type2 == 1, "exper"])*result$par$gamma["exper"] + mean(data[data$type2 == 1, "age"])*result$par$gamma["age"]
beta1  <- result$par$beta["train_cl1"]
beta2  <- result$par$beta["train_cl2"]
pdf("plot_after_estim.pdf", width=7, height=7)
	plot(data$train, data$prod, main="Avg. Effect of Training on Productivity (K=2 Model)", xlab="train", ylab="prod", col=data$type_color)
	abline(const1, beta1, col="#ff0000")
	abline(const2, beta2, col="#0000ff")
	legend("bottom", c("Type 1","Type 2"), lty=1, col=c("#ff0000","#0000ff"))
dev.off()



# What about K=3 types?
result3 <- f.estim(
	datin = data,                # Data set used for the estimation
	pind  = "SubjID",            # Name of the Subject ID (which has to be numeric)
	yind  = "prod",              # Name of the dependent variable (which has to be numeric)
	xind  = c("const","train"),  # Names of the type-specific regressors (which have to be numeric; the constant should be first)
	zind  = c("exper", "age"),   # Names of the common regressors (which have to be numeric)
	nc    = 3,                   # Number of types
	algorithm = "EM"             # Whether to use the standard ("EM") or the simulated annealing version ("SAEM") of the EM algorithm
)

# Plot the histograms of the ex post probabilities of individual type-membership
pdf("tau_hist_k3.pdf", width=9, height=4)
	par(mfrow=c(1,3)) # 3 graphics in 1 row and 3 columns
	hist(result3$tau[,1],40, main="Pr. of being in Type 1 (K=3 Model)", xlab=expression(tau[1]), xlim=c(0,1))
	hist(result3$tau[,2],40, main="Pr. of being in Type 2 (K=3 Model)", xlab=expression(tau[2]), xlim=c(0,1))
	hist(result3$tau[,3],40, main="Pr. of being in Type 3 (K=3 Model)", xlab=expression(tau[3]), xlim=c(0,1))
dev.off()
